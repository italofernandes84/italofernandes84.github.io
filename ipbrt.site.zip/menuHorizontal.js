<script type="text/javascript">
$(document).ready(function("#index.html"){
    $("#bottonCetep").click(function(){
        $("#main").load("cetep.html");
    });
});
</script>